# Compilation de Car Launcher v1.24.3.1

Ce dossier est le projet Android fourni. Le workflow GitHub Actions a été ajouté pour générer automatiquement un APK debug.

## Générer l'APK avec GitHub

1. Décompresser l'archive.
2. Dans ton dépôt GitHub, téléverser le contenu du dossier `CarLauncher` (pas le ZIP en tant que fichier unique), à la racine du dépôt.
3. Enregistrer/commit les fichiers sur la branche `main` ou `master`.
4. Ouvrir l'onglet **Actions**.
5. Choisir **Build Car Launcher APK**, puis **Run workflow** si le build ne démarre pas automatiquement.
6. Ouvrir l'exécution terminée et télécharger l'artefact **car-launcher-v1.24.3.1-debug**.
7. Décompresser l'artefact et installer `app-debug.apk` sur l'autoradio.

Le workflow installe Android SDK 34, utilise Java 17 et Gradle Wrapper fourni avec le projet.

## Important : pack voiture
Le projet source inclut un pack Renault Clio 4, installé comme pack fourni au premier lancement. Il ne contient pas de pack Peugeot 207 prêt à l'emploi. Sans pack Peugeot, l'application peut être compilée et fonctionner, mais son écran voiture 3D n'affichera pas la Peugeot. Le modèle GLB Peugeot précédemment fourni n'est pas directement utilisable comme pack : cette application attend des images WebP rendues (vues de rotation, animations de portes, etc.) selon le format décrit dans `ADAPTER.md`.

## Signature
L'APK debug généré par GitHub Actions est signé avec la clé debug automatique. Pour une distribution release et des mises à jour durables, il faudra créer et conserver une clé de signature personnelle.
